library(testthat)
library(getRatio)

test_check("getRatio")

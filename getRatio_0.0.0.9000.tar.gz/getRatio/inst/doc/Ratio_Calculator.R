## ------------------------------------------------------------------------
library(getRatio)

getRatio(Bone, "Bacterial.DNA", "Human.DNA", "HuBac")


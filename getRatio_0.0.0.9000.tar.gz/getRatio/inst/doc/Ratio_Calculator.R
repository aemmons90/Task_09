## ------------------------------------------------------------------------
library(getRatio)

getRatio(x, "Bacterial.DNA", "Human.DNA", "HuBac")

